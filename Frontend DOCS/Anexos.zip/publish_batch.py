    def publish_raw(self, env: TelemetryEnvelope) -> bool:
        import json
        info = self._client.publish(
            self._topic, payload=json.dumps(env.to_dict()), qos=self._cfg["qos"]
        )
        return info.rc == mqtt.MQTT_ERR_SUCCESS