# gateway/main.py
"""Ponto de entrada: coleta OPC UA -> envelope -> buffer -> MQTT.

Regra de aceite: queda de rede nunca produz "estado atual" falso;
envelopes com quality != GOOD são publicados com a qualidade real.
"""
import asyncio
import logging
import signal
import sys
from pathlib import Path

import yaml
from dotenv import load_dotenv

from .buffer import EventBuffer
from .mqtt_publisher import MqttPublisher
from .opcua_collector import OpcUaCollector
from .envelope import TelemetryEnvelope

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
log = logging.getLogger("gateway")


def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


class Gateway:
    def __init__(self, cfg: dict) -> None:
        self.cfg = cfg
        self.buffer = EventBuffer(
            cfg["buffer"]["db_path"], cfg["buffer"].get("max_events", 500_000)
        )
        self.collector = OpcUaCollector(cfg["opcua"], cfg["unit_id"], cfg["asset_id"])
        self.publisher = MqttPublisher(cfg["mqtt"], cfg["unit_id"], cfg["asset_id"])
        self._stop = asyncio.Event()

    def _on_batch(self, batch):
        envelopes = []
        for env in batch:
            seq = self.buffer.next_sequence()
            envelopes.append(TelemetryEnvelope(
                unit_id=env.unit_id, asset_id=env.asset_id, tag=env.tag,
                value=env.value, unit=env.unit,
                source_timestamp=env.source_timestamp,
                received_timestamp=env.received_timestamp,
                sequence=seq, quality=env.quality, origin=env.origin,
            ))
            self.buffer.append(envelopes[-1].to_dict())
        # Tenta publicar; o que não sair fica no buffer para flush posterior
        for env in envelopes:
            try:
                info = self.publisher.publish_raw(env)
                if info:
                    self.buffer.acknowledge(env.sequence)
            except Exception:
                pass  # permanece no buffer; flush resolve após reconexão

    async def _flush_loop(self):
        while not self._stop.is_set():
            await self.publisher.wait_connected()
            for env in self.buffer.pending():
                payload = TelemetryEnvelope(**env)
                try:
                    if self.publisher.publish_raw(payload):
                        self.buffer.acknowledge(payload.sequence)
                    else:
                        break
                except Exception:
                    break
            await asyncio.sleep(2)

    async def run(self):
        await self.publisher.start()
        tasks = [
            asyncio.create_task(self.collector.run(self._on_batch)),
            asyncio.create_task(self._flush_loop()),
        ]
        await self._stop.wait()
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.buffer.close()


async def _main() -> int:
    load_dotenv()
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    cfg = load_config(cfg_path)
    gw = Gateway(cfg)

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, gw._stop.set)

    await gw.run()
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(_main()))