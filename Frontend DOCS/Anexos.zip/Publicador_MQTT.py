# gateway/mqtt_publisher.py
"""Publicador MQTT sobre TLS com QoS 1 e flush do buffer persistente."""
import asyncio
import logging
import os
from typing import Callable, List

import paho.mqtt.client as mqtt
from paho.mqtt.enums import CallbackAPIVersion

from .envelope import TelemetryEnvelope

log = logging.getLogger("gateway.mqtt")


class MqttPublisher:
    def __init__(self, cfg: dict, unit_id: str, asset_id: str) -> None:
        self._cfg = cfg
        self._topic = cfg["topic_template"].format(unit_id=unit_id, asset_id=asset_id)
        self._connected = asyncio.Event()
        self._client = mqtt.Client(
            callback_api_version=CallbackAPIVersion.VERSION2,
            client_id=cfg["client_id"],
        )
        self._client.tls_set(ca_certs=cfg["ca_cert"])
        self._client.username_pw_set(
            os.environ[cfg["username_env"]], os.environ[cfg["password_env"]]
        )
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect

    def _on_connect(self, client, userdata, flags, reason_code, properties):
        if reason_code == 0:
            log.info("Broker conectado (TLS).")
            self._connected.set()

    def _on_disconnect(self, client, userdata, disconnect_flags, reason_code, properties):
        self._connected.clear()
        log.warning("Broker desconectado (%s).", reason_code)

    async def start(self) -> None:
        self._client.connect_async(self._cfg["host"], self._cfg["port"])
        self._client.loop_start()

    async def wait_connected(self, timeout: float = 15.0) -> bool:
        try:
            await asyncio.wait_for(self._connected.wait(), timeout)
            return True
        except asyncio.TimeoutError:
            return False

    def publish_batch(self, envelopes: List[TelemetryEnvelope]) -> List[int]:
        """Retorna as sequências aceitas pelo broker (QoS 1)."""
        acked: List[int] = []
        for env in envelopes:
            info = self._client.publish(
                self._topic, payload=env.to_json() if hasattr(env, "to_json")
                else __import__("json").dumps(env.to_dict()),
                qos=self._cfg["qos"],
            )
            if info.rc == mqtt.MQTT_ERR_SUCCESS:
                acked.append(env.sequence)
        return acked

    async def stop(self) -> None:
        self._client.loop_stop()
        self._client.disconnect()