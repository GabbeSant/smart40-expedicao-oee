# gateway/buffer.py
"""Fila persistente em SQLite para eventos publicados com QoS 1.

Garante que queda de rede ou do broker não perca telemetria e que a
sequência sobreviva a reinícios do processo.
"""
import json
import sqlite3
from pathlib import Path
from typing import Iterator

_SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    seq        INTEGER PRIMARY KEY,
    payload    TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


class EventBuffer:
    def __init__(self, db_path: str, max_events: int = 500_000) -> None:
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()
        self._max_events = max_events

    def next_sequence(self) -> int:
        cur = self._conn.execute(
            "SELECT COALESCE(MAX(seq), 0) + 1 FROM events"
        )
        return int(cur.fetchone()[0])

    def append(self, payload: dict) -> None:
        self._conn.execute(
            "INSERT INTO events (seq, payload, created_at) VALUES (?, ?, ?)",
            (payload["sequence"], json.dumps(payload), payload["received_timestamp"]),
        )
        self._conn.commit()
        self._trim()

    def pending(self, batch: int = 500) -> Iterator[dict]:
        cur = self._conn.execute(
            "SELECT seq, payload FROM events ORDER BY seq ASC LIMIT ?", (batch,)
        )
        for _, raw in cur.fetchall():
            yield json.loads(raw)

    def acknowledge(self, seq: int) -> None:
        self._conn.execute("DELETE FROM events WHERE seq = ?", (seq,))
        self._conn.commit()

    def _trim(self) -> None:
        self._conn.execute(
            "DELETE FROM events WHERE seq NOT IN "
            "(SELECT seq FROM events ORDER BY seq DESC LIMIT ?)",
            (self._max_events,),
        )
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()