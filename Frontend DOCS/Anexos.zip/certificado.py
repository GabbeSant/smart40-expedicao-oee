# scripts/generate_certs.py
"""Gera o par de certificados do gateway (RSA 2048, SHA-256).

O Application URI do certificado DEVE ser igual ao application_uri
definido no config.yaml, senão o servidor S7 rejeita a sessão.
"""
from datetime import datetime, timedelta, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

APPLICATION_URI = "urn:unidade-sp-01:gateway:opcua"
COMMON_NAME = "gateway-unidade-sp-01"
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "certs"
VALIDITY_DAYS = 825


def generate() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, COMMON_NAME),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Implementacao Propria"),
    ])

    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + timedelta(days=VALIDITY_DAYS))
        .add_extension(
            x509.SubjectAlternativeName([x509.UniformResourceIdentifier(APPLICATION_URI)]),
            critical=False,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, key_encipherment=True,
                content_commitment=False, key_agreement=False,
                key_cert_sign=False, crl_sign=False,
                encipher_only=False, decipher_only=False,
                data_encipherment=False, non_repudiation=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.CLIENT_AUTH]),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )

    cert_path = OUTPUT_DIR / "client_cert.pem"
    key_path = OUTPUT_DIR / "client_key.pem"
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
    )
    key_path.chmod(0o600)  # chave privada restrita ao dono do processo
    print(f"Certificado: {cert_path}\nChave:       {key_path}")


if __name__ == "__main__":
    generate()