# gateway/envelope.py
"""Envelope de telemetria — contrato único entre coletor, buffer e broker."""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Optional


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


@dataclass(frozen=True)
class TelemetryEnvelope:
    unit_id: str
    asset_id: str
    tag: str                 # nome semântico (nunca endereço do CLP)
    value: Any
    unit: Optional[str]      # unidade física ou tipo (boolean, contador, enum)
    source_timestamp: str    # timestamp do CLP (DataValue.SourceTimestamp)
    received_timestamp: str  # momento da leitura no gateway
    sequence: int            # monotônico e persistido
    quality: str             # GOOD | UNCERTAIN | BAD
    origin: str              # measured | calculated | simulated

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def now_iso() -> str:
        return _utc_now_iso()