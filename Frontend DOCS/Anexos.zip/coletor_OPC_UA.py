# gateway/opcua_collector.py
"""Coletor OPC UA com Basic256Sha256 / SignAndEncrypt e pinning do servidor.

Leitura por polling (read_data_values), que retorna DataValue completo
com StatusCode e SourceTimestamp — base para os campos quality e
source_timestamp do envelope. Somente leitura: nenhuma chamada de escrita.
"""
import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, List, Optional

from asyncua import Client, ua

from .envelope import TelemetryEnvelope

log = logging.getLogger("gateway.opcua")

_STATUS_MAP = {
    ua.StatusCode.Good: "GOOD",
    ua.StatusCode.Uncertain: "UNCERTAIN",
    ua.StatusCode.Bad: "BAD",
}


@dataclass(frozen=True)
class TagSpec:
    name: str
    node_id: str
    unit: Optional[str]


class OpcUaCollector:
    def __init__(self, cfg: dict, unit_id: str, asset_id: str) -> None:
        self._cfg = cfg
        self._unit_id = unit_id
        self._asset_id = asset_id
        self._tags: List[TagSpec] = [
            TagSpec(t["name"], t["node_id"], t.get("unit")) for t in cfg["tags"]
        ]

    def _read_file(self, relative: str) -> bytes:
        return Path(relative).read_bytes()

    async def connect(self) -> Client:
        oc = self._cfg
        client = Client(url=oc["endpoint"], timeout=oc.get("session_timeout_ms", 60_000))
        client.application_uri = oc["application_uri"]

        # Credenciais de aplicação (usuário somente leitura no CLP)
        if oc.get("auth_mode") == "username":
            import os
            client.set_user(os.environ[oc["username_env"]])
            client.set_password(os.environ[oc["password_env"]])

        # Segurança: Basic256Sha256 + SignAndEncrypt (produção)
        if oc["message_security"] != "SignAndEncrypt":
            raise ValueError("Produção exige MessageSecurityMode.SignAndEncrypt")

        await client.set_security(
            ua.MessageSecurityMode.SignAndEncrypt,  # placeholder substituído abaixo
        ) if False else None  # ver connect_secure()

        return client

    async def connect_secure(self) -> Client:
        """Monta a sessão segura com certificado de cliente e pinning do servidor."""
        oc = self._cfg
        client = Client(url=oc["endpoint"], timeout=oc.get("session_timeout_ms", 60_000))
        client.application_uri = oc["application_uri"]

        import os
        if oc.get("auth_mode") == "username":
            client.set_user(os.environ[oc["username_env"]])
            client.set_password(os.environ[oc["password_env"]])

        from asyncua.crypto.security_policies import SecurityPolicyBasic256Sha256

        cert_bytes = self._read_file(oc["client_cert"])
        key_bytes = self._read_file(oc["client_key"])
        server_cert_bytes = self._read_file(oc["server_cert"])

        await client.set_security(
            SecurityPolicyBasic256Sha256,
            certificate=cert_bytes,
            private_key=key_bytes,
            server_certificate=server_cert_bytes,   # pinning: rejeita outro servidor
            mode=ua.MessageSecurityMode.SignAndEncrypt,
        )
        return client

    async def poll_once(self, client: Client) -> List[TelemetryEnvelope]:
        nodes = [client.get_node(t.node_id) for t in self._tags]
        data_values = await client.read_data_values(nodes)
        received = TelemetryEnvelope.now_iso()
        envelopes: List[TelemetryEnvelope] = []

        for tag, dv in zip(self._tags, data_values):
            status_name = _STATUS_MAP.get(dv.StatusCode_.value, "BAD") \
                if hasattr(dv.StatusCode_, "value") else "BAD"
            source_ts = dv.SourceTimestamp
            source_iso = (
                source_ts.astimezone(timezone.utc).isoformat(timespec="milliseconds")
                if isinstance(source_ts, datetime) else received
            )
            envelopes.append(TelemetryEnvelope(
                unit_id=self._unit_id,
                asset_id=self._asset_id,
                tag=tag.name,
                value=dv.Value.Value if dv.Value is not None else None,
                unit=tag.unit,
                source_timestamp=source_iso,
                received_timestamp=received,
                sequence=0,  # preenchido pelo orquestrador
                quality=status_name,
                origin="measured",
            ))
        return envelopes

    async def run(self, on_batch: Callable[[List[TelemetryEnvelope]], None]) -> None:
        interval = self._cfg.get("poll_interval_ms", 1000) / 1000.0
        while True:
            client = None
            try:
                client = await self.connect_secure()
                log.info("Sessão OPC UA estabelecida (Basic256Sha256/SignAndEncrypt).")
                while True:
                    batch = await self.poll_once(client)
                    if batch:
                        on_batch(batch)
                    await asyncio.sleep(interval)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                log.warning("Falha OPC UA: %s. Reconexão em 5 s.", exc)
                await asyncio.sleep(5)
            finally:
                if client is not None:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass